@extends('layouts.app')
@section('title', $post['title'] . ' — Cabinet Rodilène')

@section('content')

{{-- Fil d'Ariane --}}
<section style="padding: 24px 0 0;">
    <div class="container">
        <div style="font-size: 0.85rem; color: var(--md-outline);">
            <a href="{{ route('home') }}" style="color: var(--md-outline);">Accueil</a>
            <span style="margin: 0 8px;">›</span>
            <a href="{{ route('blog.index') }}" style="color: var(--md-outline);">Actualités</a>
            <span style="margin: 0 8px;">›</span>
            <span>{{ $post['category'] }}</span>
        </div>
    </div>
</section>

{{-- En-tête article --}}
<section style="padding: 24px 0 32px;">
    <div class="container">
        <div style="max-width: 780px;">
            <span style="display: inline-block; background: var(--md-primary-container); color: var(--md-on-primary-container); padding: 4px 12px; border-radius: 100px; font-size: 0.8rem; font-weight: 500; margin-bottom: 16px;">
                {{ $post['category'] }}
            </span>
            <h1 style="font-size: 2.25rem; font-weight: 600; letter-spacing: -0.75px; line-height: 1.2; margin: 0 0 20px;">
                {{ $post['title'] }}
            </h1>
            <div style="display: flex; align-items: center; gap: 16px; color: var(--md-outline); font-size: 0.9rem; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="material-symbols-outlined" style="color: var(--md-primary);">account_circle</span>
                    <span style="color: var(--md-on-surface); font-weight: 500;">{{ $post['author'] }}</span>
                </div>
                <span>·</span>
                <span>{{ \Carbon\Carbon::parse($post['date'])->translatedFormat('d F Y') }}</span>
                <span>·</span>
                <span>{{ $post['reading_time'] }} min de lecture</span>
            </div>
        </div>
    </div>
</section>

{{-- Image principale --}}
<section style="padding: 0 0 40px;">
    <div class="container">
        <img src="{{ $post['image'] }}" alt="{{ $post['title'] }}"
             style="width: 100%; max-height: 480px; object-fit: cover; border-radius: 16px;">
    </div>
</section>

{{-- Contenu + sidebar --}}
<section style="padding: 0 0 64px;">
    <div class="container">
        <div class="row">
            {{-- Article --}}
            <div class="col s12 m8">
                <article style="font-size: 1.05rem; line-height: 1.75; color: var(--md-on-surface);">
                    @foreach(explode("\n\n", $post['content']) as $paragraph)
                        <p style="margin-bottom: 1.25rem;">{{ $paragraph }}</p>
                    @endforeach
                </article>

                {{-- Auteur --}}
                <div class="card-material" style="padding: 24px; margin-top: 40px; display: flex; gap: 16px; align-items: center;">
                    <span class="material-symbols-outlined" style="font-size: 48px; color: var(--md-primary);">account_circle</span>
                    <div>
                        <div style="font-weight: 600;">{{ $post['author'] }}</div>
                        <div style="color: var(--md-outline); font-size: 0.9rem;">{{ $post['author_role'] }}</div>
                    </div>
                </div>
            </div>

            {{-- Sidebar --}}
            <div class="col s12 m4">
                <div class="card-material" style="padding: 24px; margin-bottom: 24px;">
                    <h5 style="font-size: 1rem; font-weight: 600; margin: 0 0 16px;">Besoin d'un conseil ?</h5>
                    <p style="color: var(--md-outline); font-size: 0.9rem; line-height: 1.5; margin-bottom: 16px;">
                        Chaque situation est unique. Notre cabinet vous accompagne dans vos démarches.
                    </p>
                    <a href="{{ route('contact.index') }}" class="btn btn-material waves-effect" style="width: 100%; font-size: 0.9rem;">
                        Prendre rendez-vous
                    </a>
                </div>

                @if(count($related) > 0)
                    <div class="card-material" style="padding: 24px;">
                        <h5 style="font-size: 1rem; font-weight: 600; margin: 0 0 16px;">À lire aussi</h5>
                        @foreach($related as $r)
                            <a href="{{ route('blog.show', $r['slug']) }}" style="display: block; padding: 12px 0; border-top: 1px solid var(--md-surface-variant); text-decoration: none;">
                                <div style="font-size: 0.75rem; color: var(--md-primary); font-weight: 600; text-transform: uppercase;">
                                    {{ $r['category'] }}
                                </div>
                                <div style="font-size: 0.95rem; font-weight: 500; color: var(--md-on-surface); line-height: 1.4; margin-top: 4px;">
                                    {{ $r['title'] }}
                                </div>
                            </a>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>
    </div>
</section>

{{-- Retour --}}
<section style="padding: 0 0 48px;">
    <div class="container">
        <a href="{{ route('blog.index') }}" style="color: var(--md-primary); font-weight: 500; text-decoration: none;">
            ← Retour aux actualités
        </a>
    </div>
</section>

@endsection