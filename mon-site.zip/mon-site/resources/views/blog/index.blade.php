@extends('layouts.app')
@section('title', 'Actualités juridiques — Cabinet Rodilène')

@section('content')

{{-- En-tête de section --}}
<section style="padding: 48px 0 24px;">
    <div class="container">
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 8px;">Actualités du cabinet</h1>
        <p style="color: var(--md-outline); font-size: 1.1rem; margin: 0;">
            Décryptages, jurisprudences et conseils pratiques par nos avocats.
        </p>
    </div>
</section>

{{-- Article vedette --}}
@if($featured && !$category)
<section style="padding: 16px 0 48px;">
    <div class="container">
        <article class="card-material" style="overflow: hidden;">
            <div class="row" style="margin-bottom: 0;">
                <div class="col s12 m6">
                    <img src="{{ $featured['image'] }}" alt="{{ $featured['title'] }}"
                         style="width: 100%; height: 100%; min-height: 340px; object-fit: cover; display: block;">
                </div>
                <div class="col s12 m6">
                    <div style="padding: 40px;">
                        <span style="display: inline-block; background: var(--md-primary-container); color: var(--md-on-primary-container); padding: 4px 12px; border-radius: 100px; font-size: 0.8rem; font-weight: 500; margin-bottom: 16px;">
                            À la une · {{ $featured['category'] }}
                        </span>
                        <h2 style="font-size: 1.75rem; font-weight: 600; letter-spacing: -0.5px; margin: 0 0 16px; line-height: 1.25;">
                            {{ $featured['title'] }}
                        </h2>
                        <p style="color: var(--md-outline); font-size: 1rem; line-height: 1.6; margin-bottom: 24px;">
                            {{ $featured['excerpt'] }}
                        </p>
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 24px;">
                            <span class="material-symbols-outlined" style="color: var(--md-primary);">account_circle</span>
                            <div>
                                <div style="font-weight: 500; font-size: 0.9rem;">{{ $featured['author'] }}</div>
                                <div style="color: var(--md-outline); font-size: 0.8rem;">
                                    {{ \Carbon\Carbon::parse($featured['date'])->translatedFormat('d F Y') }} · {{ $featured['reading_time'] }} min de lecture
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('blog.show', $featured['slug']) }}" class="btn btn-material waves-effect">
                            Lire l'article
                        </a>
                    </div>
                </div>
            </div>
        </article>
    </div>
</section>
@endif

{{-- Filtres par catégorie --}}
<section style="padding: 16px 0;">
    <div class="container">
        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
            <span style="color: var(--md-outline); font-size: 0.9rem; margin-right: 8px;">Filtrer :</span>
            <a href="{{ route('blog.index') }}"
               style="padding: 8px 16px; border-radius: 100px; font-size: 0.9rem; text-decoration: none;
                      {{ !$category ? 'background: var(--md-primary); color: #fff;' : 'background: var(--md-surface-variant); color: var(--md-on-surface);' }}">
                Tous
            </a>
            @foreach($categories as $cat)
                <a href="{{ route('blog.index', ['category' => $cat['slug']]) }}"
                   style="padding: 8px 16px; border-radius: 100px; font-size: 0.9rem; text-decoration: none;
                          {{ $category === $cat['slug'] ? 'background: var(--md-primary); color: #fff;' : 'background: var(--md-surface-variant); color: var(--md-on-surface);' }}">
                    {{ $cat['name'] }} <span style="opacity: 0.6;">({{ $cat['count'] }})</span>
                </a>
            @endforeach
        </div>
    </div>
</section>
{{-- Grille des articles --}}
<section style="padding: 32px 0 64px;">
    <div class="container">
        @if(count($posts) === 0)
            <div class="card-material" style="padding: 48px; text-align: center;">
                <span class="material-symbols-outlined" style="font-size: 48px; color: var(--md-outline);">article</span>
                <p style="color: var(--md-outline); margin-top: 16px;">Aucun article dans cette catégorie pour le moment.</p>
            </div>
        @else
            <div class="row">
                @foreach($posts as $post)
                    <div class="col s12 m6 l4">
                        <article class="card-material" style="overflow: hidden; height: 100%; display: flex; flex-direction: column;">
                            <a href="{{ route('blog.show', $post['slug']) }}" style="display: block;">
                                <img src="{{ $post['image'] }}" alt="{{ $post['title'] }}"
                                     style="width: 100%; height: 200px; object-fit: cover;">
                            </a>
                            <div style="padding: 24px; flex: 1; display: flex; flex-direction: column;">
                                <span style="color: var(--md-primary); font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
                                    {{ $post['category'] }}
                                </span>
                                <h3 style="font-size: 1.15rem; font-weight: 500; line-height: 1.35; margin: 8px 0 12px;">
                                    <a href="{{ route('blog.show', $post['slug']) }}" style="color: var(--md-on-surface); text-decoration: none;">
                                        {{ $post['title'] }}
                                    </a>
                                </h3>
                                <p style="color: var(--md-outline); font-size: 0.9rem; line-height: 1.5; margin: 0 0 16px; flex: 1;">
                                    {{ \Illuminate\Support\Str::limit($post['excerpt'], 110) }}
                                </p>
                                <div style="font-size: 0.8rem; color: var(--md-outline); border-top: 1px solid var(--md-surface-variant); padding-top: 12px;">
                                    {{ \Carbon\Carbon::parse($post['date'])->translatedFormat('d M Y') }} · {{ $post['reading_time'] }} min
                                </div>
                            </div>
                        </article>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</section>

@endsection