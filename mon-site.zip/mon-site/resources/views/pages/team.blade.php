@extends('layouts.app')
@section('title', 'Notre équipe — Cabinet Rodilène')

@section('content')
<section style="padding: 64px 0;">
    <div class="container">
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 8px;">Notre équipe</h1>
        <p style="color: var(--md-outline); font-size: 1.1rem; margin-bottom: 48px;">
            Des avocats spécialisés, disponibles et engagés à vos côtés.
        </p>

        <div class="row">
            @foreach($members as $member)
                <div class="col s12 m6 l3">
                    <div class="card-material" style="overflow: hidden; height: 100%;">
                        <img src="{{ asset($member['img']) }}" alt="{{ $member['name'] }}"
                             style="width: 100%; height: 280px; object-fit: cover; display: block;">
                        <div style="padding: 20px;">
                            <h5 style="font-weight: 500; font-size: 1.1rem; margin: 0 0 4px;">{{ $member['name'] }}</h5>
                            <p style="color: var(--md-primary); font-size: 0.85rem; font-weight: 500; margin: 0 0 12px;">
                                {{ $member['role'] }}
                            </p>
                            @if(isset($member['bio']))
                                <p style="color: var(--md-outline); font-size: 0.85rem; line-height: 1.5; margin: 0;">
                                    {{ $member['bio'] }}
                                </p>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection