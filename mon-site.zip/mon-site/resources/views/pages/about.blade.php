@extends('layouts.app')
@section('title', 'À propos')

@section('content')
<section class="max-w-4xl mx-auto px-4 py-16">
    <h1 class="text-4xl font-bold mb-8">À propos de nous</h1>
    <p class="text-lg text-gray-700 mb-4">
        Fondée en 2020, notre entreprise accompagne les marques dans leur transformation digitale.
    </p>
    <p class="text-lg text-gray-700">
        Notre mission : créer des solutions web simples, élégantes et performantes.
    </p>
</section>
@endsection