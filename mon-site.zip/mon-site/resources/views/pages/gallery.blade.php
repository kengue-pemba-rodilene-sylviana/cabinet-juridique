@extends('layouts.app')
@section('title', 'Galerie')

@section('content')
<section class="max-w-6xl mx-auto px-4 py-16">
    <h1 class="text-4xl font-bold mb-12 text-center">Notre galerie</h1>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        @for($i = 1; $i <= 9; $i++)
            <div class="aspect-square bg-gradient-to-br from-indigo-400 to-purple-500 rounded-xl flex items-center justify-center text-white text-3xl font-bold">
                {{ $i }}
            </div>
        @endfor
    </div>
</section>
@endsection