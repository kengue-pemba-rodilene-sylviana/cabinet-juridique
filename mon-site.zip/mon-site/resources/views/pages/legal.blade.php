@extends('layouts.app')
@section('title', 'Mentions légales — Cabinet Rodilène & Associés')

@section('content')

{{-- En-tête --}}
<section style="padding: 64px 0 32px; border-bottom: 1px solid var(--md-surface-variant);">
    <div class="container">
        <p style="font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: var(--md-primary); margin-bottom: 12px;">
            Informations légales
        </p>
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 12px;">Mentions légales</h1>
        <p style="color: var(--md-outline); font-size: 1rem; max-width: 680px; margin: 0;">
            Conformément aux dispositions des articles 6-III et 19 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique (LCEN), nous portons à votre connaissance les présentes mentions légales.
        </p>
        <p style="color: var(--md-outline); font-size: 0.85rem; margin-top: 16px;">
            Dernière mise à jour : {{ \Carbon\Carbon::now()->translatedFormat('d F Y') }}
        </p>
    </div>
</section>

{{-- Contenu : sommaire + sections --}}
<section style="padding: 48px 0 64px;">
    <div class="container">
        <div class="row">

            {{-- Sommaire (sticky) --}}
            <div class="col s12 m4 l3">
                <div class="card-material" style="padding: 24px; position: sticky; top: 24px;">
                    <h6 style="font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--md-outline); margin: 0 0 16px;">
                        Sommaire
                    </h6>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        @foreach($sections as $i => $section)
                            <li style="border-top: 1px solid var(--md-surface-variant);">
                                <a href="#{{ $section['id'] }}"
                                   style="display: block; padding: 10px 0; font-size: 0.9rem; color: var(--md-on-surface); text-decoration: none; line-height: 1.4;">
                                    <span style="color: var(--md-outline); font-size: 0.8rem; margin-right: 6px;">{{ str_pad($i + 1, 2, '0', STR_PAD_LEFT) }}.</span>
                                    {{ $section['title'] }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>

            {{-- Sections --}}
            <div class="col s12 m8 l9">
                @foreach($sections as $i => $section)
                    <article id="{{ $section['id'] }}" style="padding: 0 0 40px; margin-bottom: 40px; border-bottom: 1px solid var(--md-surface-variant);">
                        <div style="display: flex; align-items: baseline; gap: 12px; margin-bottom: 20px;">
                            <span style="font-size: 1.5rem; font-weight: 300; color: var(--md-primary); letter-spacing: -1px;">
                                {{ str_pad($i + 1, 2, '0', STR_PAD_LEFT) }}
                            </span>
                            <h2 style="font-size: 1.4rem; font-weight: 600; letter-spacing: -0.25px; margin: 0;">
                                {{ $section['title'] }}
                            </h2>
                        </div>
                        <div style="color: var(--md-on-surface); font-size: 0.98rem; line-height: 1.7;">
                            @foreach($section['content'] as $paragraph)
                                <p style="margin: 0 0 14px;">{!! $paragraph !!}</p>
                            @endforeach
                        </div>
                    </article>
                @endforeach

                {{-- Bloc de contact --}}
                <div class="card-material" style="padding: 32px; background: var(--md-primary-container); border: none; margin-top: 8px;">
                    <h3 style="font-size: 1.2rem; font-weight: 600; color: var(--md-on-primary-container); margin: 0 0 12px;">
                        Une question sur ces mentions ?
                    </h3>
                    <p style="color: var(--md-on-primary-container); opacity: 0.85; font-size: 0.95rem; line-height: 1.6; margin-bottom: 20px;">
                        Pour toute demande relative aux présentes mentions légales, à vos données personnelles ou à l'exercice de vos droits, contactez notre délégué à la protection des données.
                    </p>
                    <div style="display: flex; flex-wrap: wrap; gap: 24px; font-size: 0.9rem; color: var(--md-on-primary-container);">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="material-symbols-outlined" style="font-size: 20px;">mail</span>
                            <span>dpo@rodilene-avocats.cg</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="material-symbols-outlined" style="font-size: 20px;">call</span>
                            <span>+242 06 410 65 21</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

@endsection