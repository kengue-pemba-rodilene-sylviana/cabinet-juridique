@extends('layouts.app')
@section('title', 'Domaines d\'expertise — Cabinet Rodilène')

@section('content')

{{-- En-tête --}}
<section style="padding: 64px 0 32px;">
    <div class="container">
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 8px;">Nos domaines d'expertise</h1>
        <p style="color: var(--md-outline); font-size: 1.1rem; max-width: 640px; margin: 0;">
            Trois pratiques complémentaires, une même exigence : la précision juridique au service de vos intérêts.
        </p>
    </div>
</section>

{{-- Sommaire --}}
<section style="padding: 0 0 48px;">
    <div class="container">
        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
            @foreach($services as $i => $service)
                <a href="#{{ \Illuminate\Support\Str::slug($service['title']) }}"
                   style="padding: 8px 16px; border-radius: 100px; background: var(--md-surface-variant); color: var(--md-on-surface); text-decoration: none; font-size: 0.9rem;">
                    {{ $service['title'] }}
                </a>
            @endforeach
        </div>
    </div>
</section>

{{-- Sections détaillées --}}
@foreach($services as $i => $service)
<section id="{{ \Illuminate\Support\Str::slug($service['title']) }}" style="padding: 48px 0; {{ $i % 2 === 1 ? 'background: var(--md-surface-variant);' : '' }}">
    <div class="container">
        <div class="row" style="margin-bottom: 0; align-items: center;">
            {{-- Image (alternance gauche/droite) --}}
            <div class="col s12 m5 {{ $i % 2 === 1 ? 'push-m7' : '' }}">
                <img src="{{ $service['image'] }}" alt="{{ $service['title'] }}"
                     style="width: 100%; height: 320px; object-fit: cover; border-radius: 16px;">
            </div>

            {{-- Contenu --}}
            <div class="col s12 m7 {{ $i % 2 === 1 ? 'pull-m5' : '' }}">
                <div style="{{ $i % 2 === 1 ? 'padding-right: 48px;' : 'padding-left: 48px;' }}">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                        <span class="material-symbols-outlined" style="font-size: 32px; color: var(--md-primary);">{{ $service['icon'] }}</span>
                        <h2 style="font-size: 1.75rem; font-weight: 600; letter-spacing: -0.5px; margin: 0;">
                            {{ $service['title'] }}
                        </h2>
                    </div>
                    <p style="color: var(--md-outline); font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">
                        {{ $service['description'] }}
                    </p>
                    <h6 style="font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--md-primary); margin-bottom: 12px;">
                        Nos interventions
                    </h6>
                    <ul style="list-style: none; padding: 0; margin: 0 0 24px;">
                        @foreach($service['points'] as $point)
                            <li style="display: flex; align-items: flex-start; gap: 8px; padding: 6px 0; font-size: 0.95rem;">
                                <span class="material-symbols-outlined" style="font-size: 18px; color: var(--md-primary); margin-top: 2px;">check_circle</span>
                                <span>{{ $point }}</span>
                            </li>
                        @endforeach
                    </ul>
                    <a href="{{ route('contact.index') }}" class="btn btn-material waves-effect">
                        Discuter de mon dossier
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
@endforeach

{{-- CTA final --}}
<section style="padding: 64px 0;">
    <div class="container">
        <div class="card-material" style="padding: 48px; text-align: center; background: var(--md-primary-container);">
            <h2 style="font-size: 1.75rem; font-weight: 600; color: var(--md-on-primary-container); margin: 0 0 12px;">
                Votre situation ne rentre dans aucune case ?
            </h2>
            <p style="color: var(--md-on-primary-container); opacity: 0.8; margin-bottom: 24px;">
                Nous étudions chaque dossier individuellement. Contactez-nous pour un premier échange confidentiel.
            </p>
            <a href="{{ route('contact.index') }}" class="btn btn-material waves-effect">
                Prendre rendez-vous
            </a>
        </div>
    </div>
</section>

@endsection