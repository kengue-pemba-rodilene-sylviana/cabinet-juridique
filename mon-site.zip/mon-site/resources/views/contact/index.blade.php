@extends('layouts.app')
@section('title', 'Contact — Cabinet Rodilène')

@section('content')
<section style="padding: 64px 0;">
    <div class="container">
        <div class="row">
            <div class="col s12 m5">
                <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 24px;">Prendre rendez-vous</h1>
                <p style="color: var(--md-outline); margin-bottom: 32px;">
                    Décrivez brièvement votre situation. Nous vous répondrons sous 24 heures ouvrées pour fixer un premier entretien confidentiel.
                </p>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                    <span class="material-symbols-outlined" style="color: var(--md-primary);">location_on</span>
                    <span>56 rue de Mawata, 75002 Pointe-Noire</span>
                </div>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                    <span class="material-symbols-outlined" style="color: var(--md-primary);">call</span>
                    <span>+242 06 410 65 21</span>
                </div>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span class="material-symbols-outlined" style="color: var(--md-primary);">mail</span>
                    <span>cabinet@rodilene-avocats.cg</span>
                </div>
            </div>

            <div class="col s12 m6 offset-m1">
                @if(session('success'))
                    <div style="background: #e8f5e9; color: #1b5e20; padding: 16px; border-radius: 12px; margin-bottom: 24px;">
                        {{ session('success') }}
                    </div>
                @endif

                <form action="{{ route('contact.store') }}" method="POST" class="card-material" style="padding: 32px;">
                    @csrf

                    <div class="input-material input-field" style="margin-bottom: 24px;">
                        <input type="text" name="name" id="name" value="{{ old('name') }}" class="validate" required>
                        <label for="name">Nom complet</label>
                        @error('name') <span style="color: var(--md-error); font-size: 0.85rem;">{{ $message }}</span> @enderror
                    </div>

                    <div class="input-material input-field" style="margin-bottom: 24px;">
                        <input type="email" name="email" id="email" value="{{ old('email') }}" class="validate" required>
                        <label for="email">Adresse e-mail</label>
                        @error('email') <span style="color: var(--md-error); font-size: 0.85rem;">{{ $message }}</span> @enderror
                    </div>

                    <div class="input-material input-field" style="margin-bottom: 24px;">
                        <textarea name="message" id="message" class="materialize-textarea" required>{{ old('message') }}</textarea>
                        <label for="message">Décrivez votre situation</label>
                        @error('message') <span style="color: var(--md-error); font-size: 0.85rem;">{{ $message }}</span> @enderror
                    </div>

                    <button type="submit" class="btn btn-material waves-effect" style="width: 100%;">
                        Envoyer ma demande
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection