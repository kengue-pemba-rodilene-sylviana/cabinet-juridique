<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index()
    {
        return view('contact.index');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:100',
            'email' => 'required|email',
            'message' => 'required|min:10',
        ]);

        // Ici : envoi d'email ou sauvegarde en BDD
        // Mail::to('contact@monsite.com')->send(new ContactMail($validated));

        return back()->with('success', 'Votre message a bien été envoyé !');
    }
}