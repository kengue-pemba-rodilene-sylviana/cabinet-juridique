<?php

namespace App\Http\Controllers;

class PageController extends Controller
{
    public function home()
    {
        return view('pages.home');
    }

    public function about()
    {
        return view('pages.about');
    }

    public function services()
{
    $services = [
        [
            'icon' => 'business',
            'title' => 'Droit des affaires',
            'short' => 'Création, contrats, contentieux entre associés.',
            'description' => 'Nous accompagnons les entreprises de la création à la cession : rédaction de statuts, pactes d\'associés, contrats commerciaux, restructurations et contentieux entre associés. Notre approche privilégie la prévention pour éviter les litiges coûteux.',
            'points' => [
                'Création de sociétés (SARL, SAS, SCI)',
                'Pactes d\'associés et gouvernance',
                'Contrats commerciaux et distribution',
                'Cessions et acquisitions',
                'Contentieux entre associés',
            ],
            'image' => 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&q=80',
        ],
        [
            'icon' => 'work',
            'title' => 'Droit du travail',
            'short' => 'Licenciements, ruptures, harcèlement, prud\'hommes.',
            'description' => 'Employeurs comme salariés, nous intervenons sur l\'ensemble du spectre du droit social : procédures de licenciement, ruptures conventionnelles, négociation collective, harcèlement moral et sexuel, et défense devant le conseil de prud\'hommes.',
            'points' => [
                'Licenciements et ruptures conventionnelles',
                'Négociation collective et accords d\'entreprise',
                'Harcèlement moral et sexuel',
                'Contentieux prud\'homal',
                'Audits sociaux et conformité',
            ],
            'image' => 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=800&q=80',
        ],
        [
            'icon' => 'home_work',
            'title' => 'Droit immobilier',
            'short' => 'Ventes, baux, copropriété, construction.',
            'description' => 'Notre pratique couvre les transactions immobilières, les baux commerciaux et d\'habitation, la copropriété et le contentieux de la construction. Nous sécurisons vos opérations et défendons vos intérêts en cas de litige.',
            'points' => [
                'Ventes et acquisitions immobilières',
                'Baux commerciaux et d\'habitation',
                'Copropriété et assemblées générales',
                'Contentieux de la construction',
                'Promotion immobilière',
            ],
            'image' => 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80',
        ],
    ];

    return view('pages.services', compact('services'));
}

    public function gallery()
    {
        return view('pages.gallery');
    }

    public function team()
{
    $members = [
        [
            'name' => 'Maître Rodilène KENGUE',
            'role' => 'Avocate associée — Droit des affaires',
            'bio' => 'Fondatrice du cabinet, spécialiste du droit des sociétés et des fusions-acquisitions. Inscrite au Barreau de Pointe-Noire.',
            'img' => 'images/team/rodilene-kengue.jpg',
        ],
        [
            'name' => 'Maître Sylviana PEMBA',
            'role' => 'Avocate associée — Droit du travail',
            'bio' => 'Spécialiste des relations individuelles et collectives du travail. Défend employeurs et salariés devant les juridictions sociales.',
            'img' => 'images/team/sylviana-pemba.jpeg',
        ],
        [
            'name' => 'Maître Sarah MAKAYA',
            'role' => 'Avocate — Droit immobilier',
            'bio' => 'Accompagne particuliers et professionnels dans leurs transactions immobilières et contentieux de la construction.',
            'img' => 'images/team/sarah-makaya.jpg',
        ],
    ];

    return view('pages.team', compact('members'));
}

    public function legal()
{
    $sections = [
        [
            'id' => 'editeur',
            'title' => 'Éditeur du site',
            'content' => [
                'Le présent site est édité par le <strong>Cabinet Rodilène & Associés</strong>, Société d\'Exercice Libéral à Responsabilité Limitée (SELARL) au capital de 50 000 €, immatriculée au RCS de Paris sous le numéro 812 345 678.',
                'Siège social : 56 rue de Mawata, 75002 Pointe-Noire, Congo.',
                'Téléphone : +242 06 410 65 21 — E-mail : cabinet@rodilene-avocats.cg.',
                'Numéro de TVA intracommunautaire : FR 12 812345678.',
                'Directeur de la publication : Maître Rodilène KENGUE, en sa qualité de représentante légale.',
            ],
        ],
        [
            'id' => 'avocats',
            'title' => 'Avocats et Ordre professionnel',
            'content' => [
                'Les avocats du cabinet sont inscrits au <strong>Barreau de Paris</strong> et soumis aux règles déontologiques de la profession, notamment au Règlement Intérieur National (RIN) de la profession d\'avocat.',
                'Ordre des avocats de Pointe-Noire — 11 place koulou, 75001 Pointe-Noire — Téléphone : +242 06 410 65 21 — Site : avocatcongo.cg.',
                'Les avocats exercent leur activité en qualité de professionnels indépendants. Ils sont tenus au secret professionnel dans les conditions prévues par l\'article 66-5 de la loi du 31 décembre 1971.',
                'Communication électronique avec les juridictions : les avocats du cabinet sont équipés du Réseau Privé Virtuel Avocat (RPVA) et de la plateforme e-Barreau.',
            ],
        ],
        [
            'id' => 'assurance',
            'title' => 'Assurance responsabilité civile professionnelle',
            'content' => [
                'Conformément aux articles 205 et suivants du décret n° 91-1197 du 27 novembre 1991, les avocats du cabinet sont couverts par une assurance de responsabilité civile professionnelle et une assurance de garantie financière.',
                'Assureur : <strong>AXA France IARD</strong> — 313 Terrasses de l\'Arche, 92727 Nanterre Cedex.',
                'Contrat n° 123456789 — Couverture géographique : France et Union européenne.',
            ],
        ],
        [
            'id' => 'hebergement',
            'title' => 'Hébergement du site',
            'content' => [
                'Le site est hébergé par <strong>OVHcloud</strong>, SAS au capital de 500 000 fcfa, immatriculée au RCS de Lille Métropole sous le numéro 424 761 419.',
                'Siège social : 2 rue Kellermann, 59100 Roubaix, France.',
                'Téléphone : +242 06 410 65 21 .',
            ],
        ],
        [
            'id' => 'propriete',
            'title' => 'Propriété intellectuelle',
            'content' => [
                'L\'ensemble du contenu du site (textes, images, logos, structure, charte graphique) est la propriété exclusive du Cabinet Rodilène & Associés ou fait l\'objet d\'une licence d\'utilisation. Il est protégé par le Code de la propriété intellectuelle.',
                'Toute reproduction, représentation, modification ou adaptation, totale ou partielle, sans autorisation écrite préalable du cabinet est strictement interdite et constitue une contrefaçon sanctionnée par les articles L. 335-2 et suivants du Code de la propriété intellectuelle.',
            ],
        ],
        [
            'id' => 'donnees',
            'title' => 'Données personnelles (RGPD)',
            'content' => [
                'Les informations recueillies via le formulaire de contact font l\'objet d\'un traitement par le Cabinet Rodilène & Associés, en sa qualité de responsable de traitement, dans le but de répondre à votre demande et, le cas échéant, de gérer la relation client.',
                'Base légale : votre consentement (article 6.1.a du RGPD) et l\'intérêt légitime du cabinet à traiter les demandes qui lui sont adressées (article 6.1.f).',
                'Durée de conservation : 3 ans à compter du dernier contact pour les prospects, et pendant toute la durée de la relation contractuelle pour les clients, augmentée des délais de prescription légaux.',
                'Destinataires : les avocats et collaborateurs du cabinet, ainsi que les prestataires techniques agissant sur instruction du cabinet.',
                'Vous disposez des droits d\'accès, de rectification, d\'effacement, de limitation, d\'opposition et de portabilité prévus aux articles 15 à 22 du RGPD. Pour les exercer, écrivez à : <strong>dpo@rodilene-avocats.fr</strong>.',
                'Vous pouvez également introduire une réclamation auprès de la CNIL — 3 place de Fontenoy, TSA 80715, 75334 Paris Cedex 07 — cnil.fr.',
            ],
        ],
        [
            'id' => 'cookies',
            'title' => 'Cookies',
            'content' => [
                'Le site utilise uniquement des cookies strictement nécessaires à son fonctionnement (cookies de session, cookies d\'authentification). Aucun cookie publicitaire ou de mesure d\'audience tiers n\'est déposé sans votre consentement préalable.',
                'Vous pouvez configurer votre navigateur pour refuser les cookies, mais certaines fonctionnalités du site pourraient alors ne plus être disponibles.',
            ],
        ],
        [
            'id' => 'mediation',
            'title' => 'Médiation de la consommation',
            'content' => [
                'Conformément aux articles L. 611-1 et suivants du Code de la consommation, le client consommateur peut recourir gratuitement à un médiateur de la consommation en vue de la résolution amiable d\'un litige.',
                'Médiateur : <strong>Médiateur national de la profession d\'avocat</strong> — 22 rue de Londres, 75009 Paris — mediateur-avocat.fr.',
                'La saisine du médiateur suppose que le client ait préalablement tenté de résoudre le litige directement auprès du cabinet par une réclamation écrite.',
            ],
        ],
        [
            'id' => 'responsabilite',
            'title' => 'Limitation de responsabilité',
            'content' => [
                'Le cabinet s\'efforce d\'assurer l\'exactitude et la mise à jour des informations diffusées sur le site, mais ne peut garantir qu\'elles soient exemptes d\'erreurs ou d\'omissions.',
                'Les informations et analyses juridiques publiées sur le site, notamment dans la rubrique Actualités, ont une valeur informative et ne constituent pas une consultation juridique. Elles ne sauraient engager la responsabilité du cabinet ni se substituer à l\'avis personnalisé d\'un avocat sur une situation particulière.',
                'Le cabinet ne saurait être tenu responsable des dommages directs ou indirects résultant de l\'utilisation du site ou de l\'impossibilité d\'y accéder.',
            ],
        ],
        [
            'id' => 'droit',
            'title' => 'Droit applicable et juridiction compétente',
            'content' => [
                'Le présent site et ses mentions légales sont soumis au droit français.',
                'En cas de litige relatif à l\'utilisation du site, et à défaut de résolution amiable, les tribunaux de Paris seront seuls compétents, sous réserve des règles impératives protégeant les consommateurs.',
            ],
        ],
    ];

    return view('pages.legal', compact('sections'));
}
}