<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    private function getPosts(): array
    {
        return [
            [
                'slug' => 'reforme-rupture-conventionnelle-2026',
                'title' => 'Réforme de la rupture conventionnelle : ce qui change en 2026',
                'category' => 'Droit du travail',
                'category_slug' => 'travail',
                'excerpt' => 'Le décret du 12 janvier 2026 modifie les délais de rétractation et le contrôle de l\'administration. Décryptage pour les employeurs et les salariés.',
                'content' => "La rupture conventionnelle, instituée par la loi du 25 juin 2008, connaît en 2026 une réforme d'ampleur. Le décret n° 2026-42 du 12 janvier 2026 allonge le délai de rétractation de 15 à 21 jours calendaires et renforce le contrôle de la Direccte sur les motifs de la rupture.\n\nPour les employeurs, cela implique une révision des procédures internes : l'entretien préalable doit désormais être formalisé par un compte rendu signé des deux parties, et l'homologation ne peut être obtenue qu'après vérification du consentement libre et éclairé.\n\nPour les salariés, ce délai supplémentaire constitue une protection bienvenue, notamment dans les situations de pression hiérarchique. Nous recommandons à nos clients de nous consulter avant toute signature.",
                'author' => 'Maître Sylviana PEMBA',
                'author_role' => 'Avocat associé — Droit du travail',
                'date' => '2026-02-14',
                'reading_time' => 6,
                'image' => 'images/blog/rupture-conventionnelle.jpg',
                'author_image' => 'images/team/sylviana-pemba.jpeg',
                'featured' => true,
            ],
            [
                'slug' => 'pacte-associes-erreurs-frequentes',
                'title' => 'Pacte d\'associés : les 5 erreurs qui coûtent cher',
                'category' => 'Droit des affaires',
                'category_slug' => 'affaires',
                'excerpt' => 'Un pacte mal rédigé peut paralyser une société en cas de conflit. Retour sur les clauses les plus souvent mal calibrées.',
                'content' => "Le pacte d'associés est un document stratégique trop souvent signé à la hâte lors de la création d'une société. Nous avons identifié cinq erreurs récurrentes dans notre pratique contentieuse.\n\n1. L'absence de clause de sortie en cas de blocage.\n2. Une clause de non-concurrence trop large, jugée nulle par les tribunaux.\n3. L'oubli de la clause de préemption en cas de cession.\n4. Une gouvernance floue entre associés fondateurs.\n5. La non-prise en compte des évolutions fiscales.\n\nChacune de ces erreurs peut donner lieu à un contentieux long et coûteux. Nous recommandons une revue annuelle du pacte.",
                'author' => 'Maître Rodilène KENGUE',
                'author_role' => 'Avocate associée — Droit des affaires',
                'date' => '2026-01-30',
                'reading_time' => 5,
                'image' => 'images/blog/pacte-associes.jpg',
                'author_image' => 'images/team/rodilene-kengue.jpg',
                'featured' => false,
            ],
            [
                'slug' => 'bail-commercial-negociation',
                'title' => 'Bail commercial : négocier avant de signer',
                'category' => 'Droit immobilier',
                'category_slug' => 'immobilier',
                'excerpt' => 'Le renouvellement d\'un bail commercial est un moment stratégique. Anticiper les clauses évite les mauvaises surprises.',
                'content' => "Le bail commercial 3-6-9 est encadré par le Code de commerce, mais la marge de négociation reste importante à chaque renouvellement.\n\nNous conseillons systématiquement à nos clients preneurs de vérifier trois éléments : le montant du loyer de renouvellement (déplafonnement possible), la répartition des charges et travaux, et la clause de destination des lieux.\n\nPour les bailleurs, l'anticipation permet d'éviter un contentieux devant le tribunal judiciaire qui peut durer 18 à 24 mois.",
                'author' => 'Maître Sarah MAKAYA',
                'author_role' => 'Avocate — Droit immobilier',
                'date' => '2026-01-12',
                'reading_time' => 4,
                'image' => 'images/blog/bail-commercial.jpg',
                'author_image' => 'images/team/sarah-makaya.jpg',
                'featured' => false,
            ],
            
        ];
    }

    public function index(Request $request)
    {
        $allPosts = $this->getPosts();
        $category = $request->query('category');

        $posts = $category
            ? array_values(array_filter($allPosts, fn($p) => $p['category_slug'] === $category))
            : $allPosts;

        $featured = collect($allPosts)->firstWhere('featured', true);
        $categories = collect($allPosts)
            ->groupBy('category_slug')
            ->map(fn($g) => [
                'slug' => $g->first()['category_slug'],
                'name' => $g->first()['category'],
                'count' => $g->count(),
            ])
            ->values()
            ->all();

        return view('blog.index', compact('posts', 'featured', 'categories', 'category'));
    }

    public function show($slug)
    {
        $allPosts = $this->getPosts();
        $post = collect($allPosts)->firstWhere('slug', $slug);
        abort_if(!$post, 404);

        $related = collect($allPosts)
            ->where('slug', '!=', $slug)
            ->where('category_slug', $post['category_slug'])
            ->take(2)
            ->values()
            ->all();

        return view('blog.show', compact('post', 'related'));
    }
}