
<?php $__env->startSection('title', 'Notre équipe — Cabinet Rodilène'); ?>

<?php $__env->startSection('content'); ?>
<section style="padding: 64px 0;">
    <div class="container">
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 8px;">Notre équipe</h1>
        <p style="color: var(--md-outline); font-size: 1.1rem; margin-bottom: 48px;">
            Des avocats spécialisés, disponibles et engagés à vos côtés.
        </p>

        <div class="row">
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s12 m6 l3">
                    <div class="card-material" style="overflow: hidden; height: 100%;">
                        <img src="<?php echo e(asset($member['img'])); ?>" alt="<?php echo e($member['name']); ?>"
                             style="width: 100%; height: 280px; object-fit: cover; display: block;">
                        <div style="padding: 20px;">
                            <h5 style="font-weight: 500; font-size: 1.1rem; margin: 0 0 4px;"><?php echo e($member['name']); ?></h5>
                            <p style="color: var(--md-primary); font-size: 0.85rem; font-weight: 500; margin: 0 0 12px;">
                                <?php echo e($member['role']); ?>

                            </p>
                            <?php if(isset($member['bio'])): ?>
                                <p style="color: var(--md-outline); font-size: 0.85rem; line-height: 1.5; margin: 0;">
                                    <?php echo e($member['bio']); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK\Desktop\mon-site\resources\views/pages/team.blade.php ENDPATH**/ ?>