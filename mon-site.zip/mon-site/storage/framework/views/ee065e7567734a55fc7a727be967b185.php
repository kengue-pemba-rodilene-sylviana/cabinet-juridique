
<?php $__env->startSection('title', 'Rodilène & Associés — Avocats à Paris'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero-section">
    <div class="container">
        <div class="row" style="margin-bottom: 0;">
            <div class="col s12 m7">
                <h1 style="font-weight: 600; letter-spacing: -1px; font-size: 3rem; color: var(--md-primary);">
                    Votre droit, défendu avec précision.
                </h1>
                <p style="font-size: 1.25rem; color: var(--md-outline); margin-bottom: 32px;">
                    Cabinet d'avocats au Barreau de Pointe-Noire depuis 2005. Nous accompagnons les entreprises et les particuliers dans leurs enjeux juridiques les plus sensibles.
                </p>
                <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-material waves-effect" style="padding: 0 32px;">
                    Prendre rendez-vous
                </a>
                <a href="<?php echo e(route('services')); ?>" class="btn-flat waves-effect" style="color: var(--md-primary); font-weight: 500;">
                    Nos domaines d'expertise
                </a>
            </div>
            <div class="col s12 m5">
                
                <img src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&q=80" 
                     alt="Bibliothèque juridique" 
                     style="width: 100%; border-radius: 24px; box-shadow: 0 8px 24px rgba(0,0,0,0.12);">
            </div>
        </div>
    </div>
</section>

<section style="padding: 64px 0;">
    <div class="container">
        <div class="row">
            <div class="col s12 center-align" style="margin-bottom: 48px;">
                <h2 class="section-title" style="font-size: 2rem;">Pourquoi nous confier votre dossier</h2>
            </div>
        </div>
        <div class="row">
            <div class="col s12 m4">
                <div class="card-material" style="padding: 32px; height: 100%;">
                    <span class="material-symbols-outlined" style="font-size: 40px; color: var(--md-primary);">gavel</span>
                    <h5 style="font-weight: 500; margin-top: 16px;">20 ans d'expérience</h5>
                    <p style="color: var(--md-outline);">Une pratique quotidienne devant les juridictions civiles, commerciales et prud'homales.</p>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="card-material" style="padding: 32px; height: 100%;">
                    <span class="material-symbols-outlined" style="font-size: 40px; color: var(--md-primary);">shield</span>
                    <h5 style="font-weight: 500; margin-top: 16px;">Confidentialité absolue</h5>
                    <p style="color: var(--md-outline);">Le secret professionnel est le socle de notre relation avec chaque client.</p>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="card-material" style="padding: 32px; height: 100%;">
                    <span class="material-symbols-outlined" style="font-size: 40px; color: var(--md-primary);">schedule</span>
                    <h5 style="font-weight: 500; margin-top: 16px;">Réactivité garantie</h5>
                    <p style="color: var(--md-outline);">Réponse à toute demande sous 24 heures ouvrées. Un interlocuteur dédié.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section style="padding: 64px 0; background: var(--md-surface-variant);">
    <div class="container">
        <div class="row">
            <div class="col s12 center-align" style="margin-bottom: 48px;">
                <h2 class="section-title" style="font-size: 2rem;">Nos domaines d'intervention</h2>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = [
                ['icon' => 'business', 'title' => 'Droit des affaires', 'desc' => 'Création de sociétés, contrats commerciaux, contentieux entre associés.'],
                ['icon' => 'work', 'title' => 'Droit du travail', 'desc' => 'Licenciements, ruptures conventionnelles, harcèlement, prud\'hommes.'],
                ['icon' => 'home_work', 'title' => 'Droit immobilier', 'desc' => 'Ventes, baux, copropriété, litiges de construction.'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s12 m4">
                    <div class="card-material" style="padding: 32px; height: 100%;">
                        <span class="material-symbols-outlined" style="font-size: 36px; color: var(--md-primary);"><?php echo e($service['icon']); ?></span>
                        <h5 style="font-weight: 500; margin-top: 12px;"><?php echo e($service['title']); ?></h5>
                        <p style="color: var(--md-outline);"><?php echo e($service['desc']); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row" style="margin-top: 32px;">
            <div class="col s12 center-align">
                <a href="<?php echo e(route('services')); ?>" class="btn-flat waves-effect" style="color: var(--md-primary); font-weight: 500;">
                    Voir tous nos domaines →
                </a>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK\Desktop\mon-site\resources\views/pages/home.blade.php ENDPATH**/ ?>