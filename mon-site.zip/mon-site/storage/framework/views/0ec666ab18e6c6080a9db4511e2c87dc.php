<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Cabinet d\'Avocats'); ?></title>

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Flex:opsz,wght@8..144,300..700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <style>
        :root {
            /* Palette Material 3 sobre pour cabinet d'avocats */
            --md-primary: #1a237e;        /* bleu nuit profond */
            --md-on-primary: #ffffff;
            --md-primary-container: #e8eaf6;
            --md-on-primary-container: #0d1440;
            --md-surface: #fefefe;
            --md-on-surface: #1c1b1f;
            --md-surface-variant: #f3f1f4;
            --md-outline: #79747e;
            --md-error: #ba1a1a;
        }

        body {
            font-family: 'Roboto Flex', sans-serif;
            background-color: var(--md-surface);
            color: var(--md-on-surface);
        }

       .navbar-material {
            background-color: var(--md-surface);
            border-bottom: 1px solid var(--md-outline);
            box-shadow: none;
            height: auto;
            line-height: normal;
            padding: 12px 0;
        }

        .navbar-material .nav-wrapper {
            height: auto;
            line-height: normal;
        }

        .navbar-material .nav-link {
            color: var(--md-on-surface) !important;
            font-size: 0.95rem;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 8px;
            transition: background 0.15s ease, color 0.15s ease;
            line-height: normal;
            height: auto;
            display: inline-block;
        }

        .navbar-material .nav-link:hover {
            color: var(--md-primary) !important;
            background: var(--md-surface-variant);
        }

        .navbar-material .sidenav-trigger {
            display: none;
            color: var(--md-on-surface);
        }

        @media only screen and (max-width: 992px) {
            .navbar-material .sidenav-trigger {
                display: block;
            }
            .navbar-material .brand-logo {
                font-size: 1.1rem;
            }
        }
        .navbar-material .brand-logo {
            color: var(--md-primary) !important;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        .navbar-material a {
            color: var(--md-on-surface) !important;
        }

        .navbar-material a:hover {
            color: var(--md-primary) !important;
        }

        .btn-material {
            background-color: var(--md-primary) !important;
            color: var(--md-on-primary) !important;
            border-radius: 100px;
            text-transform: none;
            font-weight: 500;
            letter-spacing: 0;
        }

        .btn-material:hover {
            background-color: #0d1440 !important;
        }

        .card-material {
            background: var(--md-surface);
            border-radius: 16px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04);
            border: 1px solid var(--md-surface-variant);
            transition: box-shadow 0.2s ease;
        }

        .card-material:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.10), 0 2px 4px rgba(0,0,0,0.06);
        }

        .section-title {
            font-weight: 500;
            letter-spacing: -0.25px;
            color: var(--md-on-surface);
        }

        .input-material input,
        .input-material textarea {
            border-bottom: 1px solid var(--md-outline) !important;
            box-shadow: none !important;
        }

        .input-material input:focus,
        .input-material textarea:focus {
            border-bottom: 2px solid var(--md-primary) !important;
            box-shadow: none !important;
        }

        .input-material label {
            color: var(--md-outline);
        }

        .input-material label.active {
            color: var(--md-primary);
        }

        .material-symbols-outlined {
            vertical-align: middle;
            font-size: 20px;
        }

        .hero-section {
            background: linear-gradient(135deg, var(--md-primary-container) 0%, #ffffff 100%);
            padding: 96px 0;
        }

        .footer-material {
            background-color: var(--md-surface-variant);
            color: var(--md-on-surface);
            padding: 48px 0 24px;
            margin-top: 96px;
            border-top: 1px solid var(--md-outline);
        }

        html {
            scroll-behavior: smooth;
        }

        /* Décalage pour que les titres ne soient pas collés au bord haut après ancre */
        [id] {
            scroll-margin-top: 24px;
        }

        /* Responsive : masquer le sommaire sticky sur mobile */
        @media only screen and (max-width: 600px) {
            .card-material[style*="position: sticky"] {
                position: static !important;
            }
        }
    </style>
</head>
<body>

    
<nav class="navbar-material">
    <div class="nav-wrapper container" style="display: flex; align-items: center; justify-content: space-between;">
        <a href="<?php echo e(route('home')); ?>" class="brand-logo" style="position: static; transform: none; color: var(--md-primary); font-weight: 600; letter-spacing: -0.5px; font-size: 1.35rem; white-space: nowrap;">
            Cabinet Rodilène & Associés
        </a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger" style="float: none; margin: 0;"><i class="material-symbols-outlined">menu</i></a>
        <ul class="hide-on-med-and-down" style="display: flex; align-items: center; gap: 8px; margin: 0; margin-left: auto;">
            <li><a href="<?php echo e(route('home')); ?>" class="nav-link">Accueil</a></li>
            <li><a href="<?php echo e(route('about')); ?>" class="nav-link">Cabinet</a></li>
            <li><a href="<?php echo e(route('services')); ?>" class="nav-link">Domaines</a></li>
            <li><a href="<?php echo e(route('team')); ?>" class="nav-link">Équipe</a></li>
            <li><a href="<?php echo e(route('blog.index')); ?>" class="nav-link">Actualités</a></li>
            <li style="margin-left: 16px;">
                <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-material waves-effect" style="margin: 0; padding: 0 24px; height: 40px; line-height: 40px;">
                    Prendre rendez-vous
                </a>
            </li>
        </ul>
    </div>
</nav>

    <ul class="sidenav" id="mobile-nav">
        <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
        <li><a href="<?php echo e(route('about')); ?>">Cabinet</a></li>
        <li><a href="<?php echo e(route('services')); ?>">Domaines</a></li>
        <li><a href="<?php echo e(route('team')); ?>">Équipe</a></li>
        <li><a href="<?php echo e(route('blog.index')); ?>">Actualités</a></li>
        <li><a href="<?php echo e(route('contact.index')); ?>">Contact</a></li>
    </ul>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="footer-material">
        <div class="container">
            <div class="row">
                <div class="col s12 m4">
                    <h5 class="section-title" style="font-size: 1.2rem; color: var(--md-primary);">Cabinet Rodilène</h5>
                    <p style="font-size: 0.9rem; opacity: 0.8;">Avocats au Barreau de Pointe-Noire<br>Droit des affaires · Travail · Immobilier</p>
                </div>
                <div class="col s12 m4">
                    <h6 class="section-title" style="font-size: 1rem;">Coordonnées</h6>
                    <p style="font-size: 0.9rem; opacity: 0.8;">
                        56 rue de Mawata, 75002 Pointe-Noire<br>
                        cabinet@rodilene-avocats.cg<br>
                        +242 06 410 65 21
                    </p>
                </div>
                <div class="col s12 m4">
                    <h6 class="section-title" style="font-size: 1rem;">Liens</h6>
                    <p style="font-size: 0.9rem; opacity: 0.8;">
                        <a href="<?php echo e(route('legal')); ?>" style="color: var(--md-primary);">Mentions légales</a><br>
                        <a href="<?php echo e(route('contact.index')); ?>" style="color: var(--md-primary);">Prendre rendez-vous</a>
                    </p>
                </div>
            </div>
            <div class="row" style="margin-bottom: 0;">
                <div class="col s12 center-align" style="font-size: 0.8rem; opacity: 0.6;">
                    &copy; <?php echo e(date('Y')); ?> Cabinet Rodilène & Associés. Tous droits réservés.
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.sidenav');
            M.Sidenav.init(elems);
        });
    </script>
</body>
</html><?php /**PATH C:\Users\HP ELITEBOOK\Desktop\mon-site\resources\views/layouts/app.blade.php ENDPATH**/ ?>