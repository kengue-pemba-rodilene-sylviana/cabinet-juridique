
<?php $__env->startSection('title', 'Actualités juridiques — Cabinet Rodilène'); ?>

<?php $__env->startSection('content'); ?>


<section style="padding: 48px 0 24px;">
    <div class="container">
        <h1 class="section-title" style="font-size: 2.5rem; margin-bottom: 8px;">Actualités du cabinet</h1>
        <p style="color: var(--md-outline); font-size: 1.1rem; margin: 0;">
            Décryptages, jurisprudences et conseils pratiques par nos avocats.
        </p>
    </div>
</section>


<?php if($featured && !$category): ?>
<section style="padding: 16px 0 48px;">
    <div class="container">
        <article class="card-material" style="overflow: hidden;">
            <div class="row" style="margin-bottom: 0;">
                <div class="col s12 m6">
                    <img src="<?php echo e($featured['image']); ?>" alt="<?php echo e($featured['title']); ?>"
                         style="width: 100%; height: 100%; min-height: 340px; object-fit: cover; display: block;">
                </div>
                <div class="col s12 m6">
                    <div style="padding: 40px;">
                        <span style="display: inline-block; background: var(--md-primary-container); color: var(--md-on-primary-container); padding: 4px 12px; border-radius: 100px; font-size: 0.8rem; font-weight: 500; margin-bottom: 16px;">
                            À la une · <?php echo e($featured['category']); ?>

                        </span>
                        <h2 style="font-size: 1.75rem; font-weight: 600; letter-spacing: -0.5px; margin: 0 0 16px; line-height: 1.25;">
                            <?php echo e($featured['title']); ?>

                        </h2>
                        <p style="color: var(--md-outline); font-size: 1rem; line-height: 1.6; margin-bottom: 24px;">
                            <?php echo e($featured['excerpt']); ?>

                        </p>
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 24px;">
                            <span class="material-symbols-outlined" style="color: var(--md-primary);">account_circle</span>
                            <div>
                                <div style="font-weight: 500; font-size: 0.9rem;"><?php echo e($featured['author']); ?></div>
                                <div style="color: var(--md-outline); font-size: 0.8rem;">
                                    <?php echo e(\Carbon\Carbon::parse($featured['date'])->translatedFormat('d F Y')); ?> · <?php echo e($featured['reading_time']); ?> min de lecture
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('blog.show', $featured['slug'])); ?>" class="btn btn-material waves-effect">
                            Lire l'article
                        </a>
                    </div>
                </div>
            </div>
        </article>
    </div>
</section>
<?php endif; ?>


<section style="padding: 16px 0;">
    <div class="container">
        <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
            <span style="color: var(--md-outline); font-size: 0.9rem; margin-right: 8px;">Filtrer :</span>
            <a href="<?php echo e(route('blog.index')); ?>"
               style="padding: 8px 16px; border-radius: 100px; font-size: 0.9rem; text-decoration: none;
                      <?php echo e(!$category ? 'background: var(--md-primary); color: #fff;' : 'background: var(--md-surface-variant); color: var(--md-on-surface);'); ?>">
                Tous
            </a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.index', ['category' => $cat['slug']])); ?>"
                   style="padding: 8px 16px; border-radius: 100px; font-size: 0.9rem; text-decoration: none;
                          <?php echo e($category === $cat['slug'] ? 'background: var(--md-primary); color: #fff;' : 'background: var(--md-surface-variant); color: var(--md-on-surface);'); ?>">
                    <?php echo e($cat['name']); ?> <span style="opacity: 0.6;">(<?php echo e($cat['count']); ?>)</span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section style="padding: 32px 0 64px;">
    <div class="container">
        <?php if(count($posts) === 0): ?>
            <div class="card-material" style="padding: 48px; text-align: center;">
                <span class="material-symbols-outlined" style="font-size: 48px; color: var(--md-outline);">article</span>
                <p style="color: var(--md-outline); margin-top: 16px;">Aucun article dans cette catégorie pour le moment.</p>
            </div>
        <?php else: ?>
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col s12 m6 l4">
                        <article class="card-material" style="overflow: hidden; height: 100%; display: flex; flex-direction: column;">
                            <a href="<?php echo e(route('blog.show', $post['slug'])); ?>" style="display: block;">
                                <img src="<?php echo e($post['image']); ?>" alt="<?php echo e($post['title']); ?>"
                                     style="width: 100%; height: 200px; object-fit: cover;">
                            </a>
                            <div style="padding: 24px; flex: 1; display: flex; flex-direction: column;">
                                <span style="color: var(--md-primary); font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
                                    <?php echo e($post['category']); ?>

                                </span>
                                <h3 style="font-size: 1.15rem; font-weight: 500; line-height: 1.35; margin: 8px 0 12px;">
                                    <a href="<?php echo e(route('blog.show', $post['slug'])); ?>" style="color: var(--md-on-surface); text-decoration: none;">
                                        <?php echo e($post['title']); ?>

                                    </a>
                                </h3>
                                <p style="color: var(--md-outline); font-size: 0.9rem; line-height: 1.5; margin: 0 0 16px; flex: 1;">
                                    <?php echo e(\Illuminate\Support\Str::limit($post['excerpt'], 110)); ?>

                                </p>
                                <div style="font-size: 0.8rem; color: var(--md-outline); border-top: 1px solid var(--md-surface-variant); padding-top: 12px;">
                                    <?php echo e(\Carbon\Carbon::parse($post['date'])->translatedFormat('d M Y')); ?> · <?php echo e($post['reading_time']); ?> min
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP ELITEBOOK\Desktop\mon-site\resources\views/blog/index.blade.php ENDPATH**/ ?>